
  package com.quest.library_management_system.repository;
  
  import org.springframework.data.jpa.repository.JpaRepository; import
  org.springframework.stereotype.Repository;
  
  import com.quest.library_management_system.models.IssueBooks;
  
  @Repository 
  public interface IssueBooksRepository extends JpaRepository<IssueBooks,Integer> {
  
  
  }
 