
package com.quest.library_management_system.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import

org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.quest.library_management_system.models.Book;
import com.quest.library_management_system.models.IssueBooks;
import com.quest.library_management_system.models.User;
import com.quest.library_management_system.repository.BookRepository; 
import com.quest.library_management_system.repository.IssueBooksRepository;
import com.quest.library_management_system.repository.UserRepository;
import com.quest.library_management_system.service.BookService;
import com.quest.library_management_system.service.UserService;
import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminController {
	
	@Autowired
	private UserRepository userrepo;
	@Autowired
	private BookRepository bookrepo;
	
	@GetMapping("/admin")
	public String showLoginPage() 
	{
		return "AdminLogin";
	}
	
	@GetMapping("/admin/home")
	public String showAdminHomePage()
	{
		return "AdminHome";
	}
	
	@PostMapping("/home")
	public String adminLogin()
	{
		return "redirect:/admin/home";
	}
	
	@GetMapping("/book")
	public String showManageBook()
	{
		return "Book";
	}
	
	@GetMapping("/user")
	public String showUsersPage()
	{
		return "Manage-Users";
	}
	
	@PutMapping("/approve/{id}")
	public ResponseEntity<String> approveUser(@PathVariable Integer id) {
		Optional<User> user = userrepo.findById(id);
		if (user == null) {
			return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
		}
		user.ifPresent(u -> u.setApporved(true));
		user.ifPresent(u -> userrepo.save(u));
		return new ResponseEntity<>("User approved successfully", HttpStatus.OK);
	}
	@PutMapping("/issuebook/{userId}/{bookId}")
	public ResponseEntity<String> issueBook(@PathVariable("userId") Integer userId,
			@PathVariable("bookId") Integer bookId) {
		Optional<User> user = userrepo.findById(userId);
		Optional<Book> book = bookrepo.findById(bookId);
		if (user == null) {
			return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
		} else {
			if (book == null) {
				return new ResponseEntity<>("Book not found", HttpStatus.NOT_FOUND);
			}
			List<Integer> issued = user.get().getBooksIssued()==null?new ArrayList<Integer>():user.get().getBooksIssued();
			issued.add(bookId);
			user.get().setBooksIssued(issued);
		}
		user.ifPresent(u -> userrepo.save(u));

		return new ResponseEntity<>("Book issued successfully", HttpStatus.OK);
	}
}
