package com.quest.library_management_system.securityConfig;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.password.NoOpPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.provisioning.JdbcUserDetailsManager;
//import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
public class securityConfig {
	
//	@Bean
//	public ViewResolver viewResolver() {
//		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
//		viewResolver.setViewClass(JstlView.class);
//		viewResolver.setPrefix("/WEB-INF/jsp/");
//		viewResolver.setSuffix(".jsp");
//		return viewResolver;
//	}
	
//	@Bean
//	SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
//		http.
//		authorizeHttpRequests()
//		.requestMatchers("/").hasAuthority("admin")		
//		.and()
//		.authorizeHttpRequests().requestMatchers("/book/update/**").hasAuthority("admin")
//		.and().formLogin().and().httpBasic();
//		http.csrf().disable();
//		return http.build();
//	}
	
	
//	@Bean
//    public DataSource datasource() {
//        return DataSourceBuilder.create()
//                .driverClassName("com.mysql.cj.jdbc.Driver")
//                .url("jdbc:mysql://localhost:3306/library_managemnt_system_db")
//                .username("root")
//                .password("root")
//                .build();
//    }
//	
//	// in approch 2 we create PasswordEncoder bean separately
//		@Bean
//		public PasswordEncoder passwordEncoder() {
//			return NoOpPasswordEncoder.getInstance();
//		}
//
//		// jdbc user details manager
//		@Bean
//		public UserDetailsService jdbcUserDetailsManager(DataSource dataSource) {
//			return new JdbcUserDetailsManager(dataSource);
//		}
//	
	
	
	}

