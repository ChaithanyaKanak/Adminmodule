package com.quest.library_management_system.models;

import java.beans.JavaBean;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.id.factory.spi.GenerationTypeStrategyRegistration;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;

@Entity
@Table(name = "User_tb")
public class User {
	@jakarta.persistence.Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;

	@Column(nullable = false)
	private String firstName;

	@Column(nullable = false)
	private String lastName;

	@Column(nullable = false)
	private String address;

	@Column(nullable = false)
	private int phonenumber;

	@Column(nullable = false)
	private String email;
	
	@Column(nullable=false)
	private boolean isApporved=false;
	@Column
	private List<Integer> booksIssued=new ArrayList<Integer>();

	public List<Integer> getBooksIssued() {
		return booksIssued;
	}

	public void setBooksIssued(List<Integer> booksIssued) {
		this.booksIssued = booksIssued;
	}

	public boolean isApporved() {
		return isApporved;
	}

	public void setApporved(boolean isApporved) {
		this.isApporved = isApporved;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;

	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public User(String firstName, String lastName, String address, int phonenumber, String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.phonenumber = phonenumber;
		this.email = email;
	}

}