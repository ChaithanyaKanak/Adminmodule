package com.quest.library_management_system.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.quest.library_management_system.models.User;
import com.quest.library_management_system.repository.UserRepository;
import jakarta.transaction.Transactional;



@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepo;

	private UserRepository userrepo;

	public UserService(UserRepository userrepo) {
		this.userrepo = userrepo;
	}

	public void savemyuser(User user) {
		userrepo.save(user);
	}

//	public List<User> findByNameLikeAndEmailLike(String FirstName, String Email) {
//		return findByNameLikeAndEmailLike("%" + FirstName + "%", "%" + Email + "%");
//	}

	public User findById(Integer id) {
		// TODO Auto-generated method stub
		return this.userRepo.getById(id);
	}

}