
package com.quest.library_management_system.models;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class IssueBooks {

	@Id

	@GeneratedValue
	private int id;
	private int userId;
	private int bookId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int u) {
		this.userId = u;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	

	public IssueBooks(int id, int userId, int bookId) {
		super();
		this.id = id;
		this.userId = userId;
		this.bookId = bookId;
	}

	public IssueBooks() { super(); // TODO Auto-generated constructor stub }
  
  }
}
