package com.quest.library_management_system.repository;
import com.quest.library_management_system.models.Book;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Integer> 
{
	 List<Book> findByTitleLikeAndAuthorLikeAndPublisherLike(String title, String author, String publisher);
}
