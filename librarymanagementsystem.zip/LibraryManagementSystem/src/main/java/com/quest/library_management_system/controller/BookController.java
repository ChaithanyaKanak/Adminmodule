package com.quest.library_management_system.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.quest.library_management_system.models.Book;
import com.quest.library_management_system.repository.BookRepository;
import com.quest.library_management_system.service.BookService;

@Controller
public class BookController 
{
	@Autowired
	private BookRepository bookrepo;

	@Autowired
	private BookService bookservice;
	
	@GetMapping("/")
	public String listAllbooks(Model model) 
	{
		List<Book> books = bookrepo.findAll();
		model.addAttribute("books",books);
		return "Book";
	}
	
	@GetMapping("/book/")
	public String showBooks()
	{
		return "book";
	}
	
	
	@PostMapping("/book/add")
	public String addBook(@RequestParam String title,
					@RequestParam String ISBN,
					@RequestParam int publicationYear,
					@RequestParam String publisher,
					@RequestParam String author,
					@RequestParam String category,
					@RequestParam int price)
	{
		Book book = new Book();
		book.setTitle(title);
		book.setISBN(ISBN);
		book.setPublicationYear(publicationYear);
		book.setPublisher(publisher);
		book.setAuthor(author);
		book.setCategory(category);
		book.setPrice(price);
		bookservice.savemybook(book);
		return "redirect:/";
	}
	
	@GetMapping("/book/update/{id}")
	public String showUpdateBooks(@PathVariable Integer id,Model model)
	{
		Book book = null;
		Optional<Book> optionalbook = bookrepo.findById(id);
		if(optionalbook.isPresent())
		{
			book = optionalbook.get();
		}
		else
		{
			return "redirect:/error/No Teacher With ID : "+id+" Found";
		}
		model.addAttribute("book",book);
		return "Update-Book";
	}
	
	@PostMapping("/book/update")
	public String updateBook(@ModelAttribute Book book)
	{
		bookservice.savemybook(book);
		return "redirect:/";
	}
	
	@GetMapping("/book/remove/{id}")
	public String removeBook(@PathVariable Integer id)
	{
		bookrepo.deleteById(id);
		return "redirect:/";
	}
	
	@PostMapping("/book/search")
    public String searchBook(@RequestParam String value ,Model model) 
		{
			List<Book> book = bookservice.findByTitleLikeAndAuthorLikeAndPublisherLike("%"+value+"%", "%"+value+"%", "%"+value+"%");
			model.addAttribute("book", book);
			return "redirect:/";
		}	
}
