package com.quest.library_management_system.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="books_tb")
public class Book 
{
	@Id
	@GeneratedValue
	private int Id;
	
	@Column(nullable = false)
	private String title;
	
	@Column(nullable = false)
	private String ISBN;
	
	@Column(nullable = false)
	private int publicationYear;
	
	@Column(nullable = false)
	private String publisher;
	
	@Column(nullable = false)
	private String author;
	
	@Column(nullable = false)
	private String category;
	
	@Column(nullable = false)
	private float price;
	
	//Constructor 
	public Book() {
	
	}

	//Getter's And Setter's
	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public int getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(int publicationYear) {
		this.publicationYear = publicationYear;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

}
