package com.quest.library_management_system.service;
import java.util.List;
import org.springframework.stereotype.Service;

import com.quest.library_management_system.models.Book;
import com.quest.library_management_system.repository.BookRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class BookService 
{
	
	private BookRepository bookrepo;
	
	
	public BookService(BookRepository bookrepo)
	{
		this.bookrepo=bookrepo;
	}
	
	public void savemybook(Book book) 
	{
		bookrepo.save(book);
	}
	
	 public List<Book> findByTitleLikeAndAuthorLikeAndPublisherLike(String title, String author, String publisher)
	 {
		 return findByTitleLikeAndAuthorLikeAndPublisherLike("%"+title+"%", "%"+author+"%", "%"+publisher+"%");
	 }

	}
	
